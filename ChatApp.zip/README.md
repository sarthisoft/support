#Step 1
npm install

Step 2 

npm start


